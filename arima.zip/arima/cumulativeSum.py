import pandas as pd
import numpy as np
from datetime import timedelta

def date_array(dataframe):
    start_date = dataframe['date'].min().to_pydatetime()
    end_date = dataframe['date'].max().to_pydatetime()
    end_date = end_date + timedelta(days=1)
    array_dates = np.arange(start_date, end_date, dtype='datetime64[D]')
    return array_dates

# this cumulative sum includes Fernando de Noronha's cases for Pernambuco
def main():
    # loading the csv file
    cases_per_state = pd.read_csv('covid19.csv', delimiter=',')
    cases_per_state['date'] = pd.to_datetime(cases_per_state['date'])

    # sorting dataset by date
    cases_per_state['date'] = pd.to_datetime(cases_per_state['date'])
    cases_per_state = cases_per_state.sort_values(by=['date'])

    #casesPE = casesPE[casesPE['city'] != 'Importados/Indefinidos']
    states = cases_per_state['state'].unique()

    for state in states:
        temp = cases_per_state[cases_per_state['state'] == state]
        dates_for_timeserie = date_array(temp)
        confirmed_cases = len(dates_for_timeserie) * [0]
        deaths_cases = len(dates_for_timeserie) * [0]
        notification_dates_array = temp['date'].values.astype('datetime64[D]')  # datas dos casos confirmados
        array_index = 0
        for day in dates_for_timeserie:
            if day in notification_dates_array:
                idx = temp[temp['date'] == day].index
                confirmed_cases[array_index] = temp['confirmed'][idx[0]]
                array_index = array_index + 1
            else:
                confirmed_cases[array_index] = confirmed_cases[array_index - 1]
                deaths_cases[array_index] = deaths_cases[array_index - 1]
                array_index = array_index + 1
        confirmed_cases_dataframe = pd.DataFrame({'notification_date':dates_for_timeserie, 'cumulative_sum_cases':confirmed_cases})
        confirmed_cases_dataframe.to_csv("confirmed cases data/baseARIMA" + "_" + state + ".csv", index=False)
        array_index = 0


main()