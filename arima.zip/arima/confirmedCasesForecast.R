#setting the worskspace
directory <- getwd()
setwd(directory)


#Load libraries
library("tseries")
library("forecast")
library("lubridate")

# Fetch command line arguments
python_arguments <- commandArgs(trailingOnly = TRUE)
print(python_arguments[[1]])
print(python_arguments[[2]])

start.year <- function(date){
  #cacth the year in which the time serie begins
  split_string <- unlist(strsplit(as.character(date),"-"))
  year <- split_string[1]
  year <- as.integer(year)
  return(year)
}

convert_date_format <- function(date){
  # modify the date format from y-m-d to d-m-y
  aux <- unlist(strsplit(as.character(date),"-"))
  date <- paste0(aux[3],"-",aux[2],"-",aux[1])
  return(date)
}

modelCoefficients <- function(model, actual_cases){
  # save a .csv file of the model coefficients
  pearson <- cor(actual_cases,model,method = "pearson")
  spearman <- cor(actual_cases,model,method = "spearman")
  kendall <- cor(actual_cases,model,method = "kendall")
  stats <- c(pearson, spearman, kendall)
  print(stats)
  return(stats)
}

model_cases_linechart <- function(arima_model, actual_cases, title, yaxis_label){
  model_cases_pngfile <- paste0("fitted model vs confirmed cases/","model","_",state,".png")
  png(file = model_cases_pngfile, width = 650, height = 500, units='px')
  plot(actual_cases, col ='blue', type='l', ylab=yaxis_label, xlab="Time", main=title)
  grid(lwd = 2, col = 'blue')
  lines(arima_model, col='red')
  legend('topleft', legend = c('Fitted', 'Actual'), col = c('red','blue'),pch = c("-","-"),text.col = "black",inset = c(0.1, 0.1))
  dev.off()
}

forecast_cases_linechart <- function(forecast_values, title, yaxis_label){
  forecast_cases_linechart_png <-  paste0("forecasts line chart/","forecast","_",state,".png")
  png(file = forecast_cases_linechart_png, width = 650, height = 500, units = 'px')
  plot(forecast_values, type='l',ylab = yaxis_label, xlab="Time", main = title)
  grid(lwd = 2, col = 'blue')
  dev.off()
  
}

csv.coefficients <- function(coefficients, folder, filename){
  df <- data.frame(coefficients[1],coefficients[2],coefficients[3])
  names(df) <- c("pearson", "spearman", "kendall")
  write.csv(df,paste0(folder,filename, state,".csv"))
}


#Load data
covid19_confirmed_cases <- read.csv(python_arguments[[1]])
  
#print(covid19_confirmed_cases)
class(covid19_confirmed_cases)
state <- python_arguments[[2]]
  
# Representing the covid-19 cases in a time-series format
timeSerie_start <- start.year(covid19_confirmed_cases$notification_date[1])
confirmed_cases_timeserie <- ts(covid19_confirmed_cases$cumulative_sum_cases,  freq = 365, start = timeSerie_start)
  
  
#Adjusting an Arima model 
fit.p <- auto.arima(confirmed_cases_timeserie) 
f.proj <- forecast(fit.p, h = 6, level = c(95))
  
coefficients.forecast <- modelCoefficients(confirmed_cases_timeserie, as.numeric(fit.p$fitted))
csv.coefficients(coefficients.forecast,"models coefficients/","coefs_proj_")

# Send the forecast information
forecast.dates <- ymd(as.Date(covid19_confirmed_cases$notification_date[length(confirmed_cases_timeserie)])) + days(1:6)
c <- cbind(forecast.dates, as.data.frame(f.proj))
write.csv(c,paste0("confirmed cases forecasts/", "forecasts_",state,".csv"))

#Line chart of the ARIMA model for covid-19
model_linechart_title <- paste0("Actual vs Predicted (ARIMA model) values for ",state," data from " ,
                                convert_date_format(covid19_confirmed_cases$notification_date[1])," to ",
                                convert_date_format(covid19_confirmed_cases$notification_date[length(confirmed_cases_timeserie)]))

model_cases_linechart(fit.p$fitted,confirmed_cases_timeserie, model_linechart_title, "COVID-19 cases")


#Line chart of the covid-19 forecast 
forecast_linechart_title <- paste0("Forecasts (6 days) of the number of COVID-19 cases for ",state," from ",
                                      convert_date_format(as.Date(covid19_confirmed_cases$notification_date[length(confirmed_cases_timeserie)])+1)," to ",
                                      convert_date_format(as.Date(covid19_confirmed_cases$notification_date[length(confirmed_cases_timeserie)])+6))

forecast_cases_linechart(f.proj, forecast_linechart_title, "COVID-19 cases")
  

