import subprocess
import os

def ConfirmedCasesProjection(predictionFile, state):
    # run ARIMA_prediction.R
    arg = [predictionFile, state]

    # Define command and arguments
    command = r'C:\Program Files\R\R-3.6.3\bin\Rscript'
    path2script = os.getcwd() + '/confirmedCasesForecast.R'

    #Build process command
    cmd = [command, '--vanilla', path2script] + arg

    #check_output will run to the command and store result
    subprocess.call(cmd)
    #print(x)


def arima_forecast():
    directory_confirmed_cases = os.getcwd() + '\confirmed cases data'
    paths_confirmed_cases = [os.path.join(directory_confirmed_cases, filename) for filename in os.listdir(directory_confirmed_cases)]
    files_confirmed_cases = [file for file in paths_confirmed_cases if os.path.isfile(file)]

    for index in range(0, len(files_confirmed_cases)):
        state_name = files_confirmed_cases[index].split("_")
        state_name = state_name[1].split(".")
        ConfirmedCasesProjection(files_confirmed_cases[index], state_name[0])


arima_forecast()

