import cumulativeSum
import arima

def main():
    cumulativeSum.main()
    arima.arima_forecast()
main()

